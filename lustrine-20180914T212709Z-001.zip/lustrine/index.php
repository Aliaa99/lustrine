<?php
include 'header.php';
?>

<div class="slides">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-8 col-sm-12">
                <div class="slide1 owl-carousel owl-theme">
                    <div class="item">
                        <img src="images/slide.png" class="animated fadeIn">
                        <div class="caption">
                            <h2>ديكور المنازل</h2>
                            <a href="#">تسوق الآن</a>
                        </div>
                    </div>
                    <div class="item">
                        <img src="images/slide.png" class="animated fadeIn">
                        <div class="caption">
                            <h2>ديكور المنازل</h2>
                            <a href="#">شراء الآن</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="vertical-slide center">
                    <div class="image-slide">
                        <img src="images/im1.png" alt="">
                        <div class="caption2">
                            <h2>كريم وجه</h2>
                            <a href="#">شراء الآن</a>
                        </div>
                    </div>
                    <div class="image-slide">
                        <img src="images/im2.png" alt="">
                        <div class="caption2">
                            <h2>كرسى مكتب</h2>
                            <a href="#">شراء الآن</a>
                        </div>
                    </div>
                    <div class="image-slide">
                        <img src="images/im2.png" alt="">
                        <div class="caption2">
                            <h2>كرسي مكتب</h2>
                            <a href="#">شراء الآن</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container-fluid">
    <!-- under carousle -->
    <div class="options">
        <div class="row">
            <div class="col-md-4">
                <div class="option">
                    <img src="images/Forma 1.png" alt="">
                    <h4>دفع آمن</h4>
                    <p>نضمن لك دفع آمن لكل العملات </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="option center-div">
                    <img src="images/Forma 2.png" alt="">
                    <h4>توصيل سريع </h4>
                    <p>سرعه عالية فى توصيل المنتجات </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="option">
                    <img src="images/Forma 3.png" alt="">
                    <h4>استرجاع المنتج </h4>
                    <p>نضمن لك استرجاع المنتج بعد 15 يوم </p>
                </div>
            </div>
        </div>
    </div>
    <!-- added new -->
    <div class="main-head" data-aos="zoom-in"
     data-aos-duration="1000">
        <h1>=<span>المضاف حديثا</span>=</h1>
    </div>
    <!--  add new products -->
    <div class="second-carousle" data-aos="fade-up"
     data-aos-duration="1000">
        <div class="slide2 owl-carousel owl-theme">
            <div class="item">
                <img src="images/chair.png" alt="">
                <div class="details">
                    <span>نجفة سوده</span>
                    <p><span>240 ر.س</span> 140ر.س</p>
                </div>
                <div class="to-buy">
                    <ul>
                        <li><button class="shope"data-placement="left"  data-toggle="tooltip" title="أضف لسلة الشراء"><i class="flaticon-shopping-cart"></i></button></li>
                        <li><button class="heart"data-placement="left"  data-toggle="tooltip" title="أضف لقائمة رغباتى"><i class="flaticon-favorite-heart-button"></i></button></li>
                        <li><button class="eye" data-placement="left" data-toggle="tooltip" title="عرض تفاصيل المنتج"><i class="flaticon-vision"></i><i class="laticon-favorite-heart-button"></i></button></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- media  -->
    <div class="media">
        <div class="row">
            <div class="col-md-3">
                <div class="right-side">
                    <p>خصم <span>50%</span> عند</p>
                </div>
            </div>
            <div class="col-md-9">
                <div class="left-side">
                    <p class="para2">افضل تجربة شراء اون لاين</p>
                    <div class="media2">اعلان</div>
                </div>
            </div>
        </div>
    </div>

    <!-- most sell new -->
    <div class="main-head"data-aos="zoom-in"
     data-aos-duration="1000">
        <h1>=<span>الأكثر مبيعا </span>=</h1>
    </div>
        <!-- products -->
    <div class="products"data-aos="flip-left"
     data-aos-duration="1000">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="images-media">
                    <a href="#">
                        <img src="images/2.png" alt="">
                        <span>تسوق الان</span>
                    </a>
                </div>
            </div>
            <div class="col-lg-9 col-md-8 col-sm-6">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="most-sell">
                            <div class="images">
                                <img src="images/1.png" alt="">
                                <div class="to-buy2">
                                    <ul>
                                        <li><button class="shope"data-placement="left"  data-toggle="tooltip" title="أضف لسلة الشراء"><i class="flaticon-shopping-cart"></i></button></li>
                                        <li><button class="heart"data-placement="left"  data-toggle="tooltip" title="أضف لقائمة رغباتى"><i class="flaticon-favorite-heart-button"></i></button></li>
                                        <li><button class="eye" data-placement="left" data-toggle="tooltip" title="عرض تفاصيل المنتج"><i class="flaticon-vision"></i><i class="laticon-favorite-heart-button"></i></button></li>
                                    </ul>
                                </div>
                            </div>
                            <h3>نجفة حلوة</h3>
                            <!--<ul>-->
                            <!--    <li><a href="#"><i class="fas fa-star"></i></a></li>-->
                            <!--    <li><a href="#"><i class="far fa-star"></i></a></li>-->
                            <!--    <li><a href="#"><i class="far fa-star"></i></a></li>-->
                            <!--    <li><a href="#"><i class="far fa-star"></i></a></li>-->
                            <!--    <li><a href="#"><i class="far fa-star"></i></a></li>-->
                            <!--</ul>-->
                            <p><span>123 ر.س</span>120 ر.س</p>
                            <!-- <button href="#" class="shopping-cart"></button> -->
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="most-sell">
                            <div class="images">
                                <img src="images/1.png" alt="">
                                <div class="to-buy2">
                                    <ul>
                                        <li><button class="shope"data-placement="left"  data-toggle="tooltip" title="أضف لسلة الشراء"><i class="flaticon-shopping-cart"></i></button></li>
                                        <li><button class="heart"data-placement="left"  data-toggle="tooltip" title="أضف لقائمة رغباتى"><i class="flaticon-favorite-heart-button"></i></button></li>
                                        <li><button class="eye" data-placement="left" data-toggle="tooltip" title="عرض تفاصيل المنتج"><i class="flaticon-vision"></i><i class="laticon-favorite-heart-button"></i></button></li>
                                    </ul>
                                </div>
                            </div>
                            <h3>نجفة حلوة</h3>
                            <!--<ul>-->
                            <!--    <li><a href="#"><i class="fas fa-star"></i></a></li>-->
                            <!--    <li><a href="#"><i class="far fa-star"></i></a></li>-->
                            <!--    <li><a href="#"><i class="far fa-star"></i></a></li>-->
                            <!--    <li><a href="#"><i class="far fa-star"></i></a></li>-->
                            <!--    <li><a href="#"><i class="far fa-star"></i></a></li>-->
                            <!--</ul>-->
                            <p><span>123 ر.س</span>120 ر.س</p>
                            <!-- <button href="#" class="shopping-cart"></button> -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- media  -->
    <div class="media">
        <div class="row">
            <div class="col-md-3">
                <div class="right-side">
                    <p>خصم <span>30%</span> عند</p>
                </div>
            </div>
            <div class="col-md-9">
                <div class="left-side">
                    <p class="para2"> المنتجات الاكثر من 300 ر.س</p>
                    <div class="media2">اعلان</div>
                </div>
            </div>
        </div>
    </div>

    <!-- markets logo -->
    <div class="company-logos owl-carousel owl-theme" data-aos="flip-right"
     data-aos-duration="1000">
        <div class="item">
            <img src="images/3.png" class="animated fadeIn">
        </div>
        <div class="item">
            <img src="images/3.png" class="animated fadeIn">
        </div>
    </div>


</div>











<?php
include 'footer.php';
?>
