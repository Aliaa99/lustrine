<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>lustraine</title>
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-rtl.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/hover-min.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slick-theme.css">
    <link rel="stylesheet" href="css/lightbox.css">
    <link rel="stylesheet" href="fonts/stylesheet.css">
    <link rel="shortcut icon" href="images/logo.png">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <div class="uper-head">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <div class="select">
                        <div class="dropdown">
                            <button href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <img src="images\ar.png" alt="" class="choose-lang-img">اللغة
                            <span class="caret"></span></button>
                            <ul class="dropdown-menu lang">
                                <li><a href="#"><img src="images\ar.png" alt="">عربى</a></li>
                                <li><a href="#"><img src="images\ar.png" alt="">english</a></li>
                            </ul>
                        </div>
                        <div class="dropdown">
                            <button href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            رأس العملة
                            <span class="caret"></span></button>
                            <ul class="dropdown-menu lang">
                                <li> <a href="#">$ دولار</a></li>
                                <li> <a href="#">$ ريال</a></li>
                            </ul>
                        </div>
                        <div class="dropdown profile">
                            <button href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            حسابى
                            <span class="caret"></span></button>
                            <ul class="dropdown-menu lang">
                                <li><a href="#">عربى</a></li>
                                <li><a href="#">english</a></li>
                            </ul>
                        </div>

                    </div>
                </div>
                <div class="col-sm-6">
                    <ul>
                        <li><a href="#" class="telephone">011449899754659</a></li>
                        <li><a href="#" class="mail">aliaa@bb4it.com</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="logo-small">
        <a href="#"><img src="images/logo.png" alt=""></a>
        <a href="#"class="side-menu"></a>
            <!--buy link in side menu-->
                    <div class="buybasket">
                        <button class="btn buylink "> <i class="flaticon-shopping-cart"></i> </button>
                    </div>
                        <div class="product-table">
                            <div class="product">
                                <ul>
                                    <li><img src="images/im1.png" alt=""></li>
                                    <li>اسم المنتج</li>
                                    <li>1</li>
                                    <li>30ر.س</li>
                                    <li><a href="#"><i class="fas fa-window-close"></i></a></li>
                                </ul>
                                <div class="table">
                                    <table class="table table-bordered">
                                        <tbody>
                                            <tr>
                                                <td class="text-right"><strong>الاجمالي</strong></td>
                                                <td class="text-right">30 ر.س</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>القيمة المضافة</strong></td>
                                                <td class="text-right">2 ر.س</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>الاجمالي النهائي</strong></td>
                                                <td class="text-right">32 ر.س</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <p><a href="#">إنهاء الطلب</a>
                                <a href="#">معاينة السلة</a>
                                </p>
                            </div>
                        </div>

    </div>
    <div class="navbar">
            <!-- close link in side menu -->
                <a href="#" class="close-link-menu">X</a>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4 col-md-8 col-sm-8">
                    <ul class="nav">
                        <li>
                            <a href="#">الرئيسية </a>
                        </li>
                        <li class="dropdown mega-dropdown" >
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
                            الأقسام
                            <span class="caret"></span>
                            </a>
                            
                                <!--dropdown menu ul -->
                            <ul class="dropdown-menu mega-dropdown-menu">
            					<li class="col-sm-3">
            					    <ul>
                                        <li class="dropdown-header">الاقسام</li>
                                        <li><a href="#">رجالى</a></li>
                                        <li><a href="#">نسائي</a></li>
                                        <li><a href="#">أطفال</a></li>
                                    </ul>
                    			</li>
            					<li class="col-sm-3">
            					    <ul>
                                        <li class="dropdown-header">الاقسام</li>
                                        <li><a href="#">رجالى</a></li>
                                        <li><a href="#">نسائي</a></li>
                                        <li><a href="#">أطفال</a></li>
                                    </ul>
                    			</li>
            					<li class="col-sm-3">
            					    <ul>
                                        <li class="dropdown-header">الاقسام</li>
                                        <li><a href="#">رجالى</a></li>
                                        <li><a href="#">نسائي</a></li>
                                        <li><a href="#">أطفال</a></li>
                                    </ul>
                    			</li>
            					<li class="col-sm-3">
            					    <ul>
                                        <li class="dropdown-header">الاقسام</li>
                                        <li><a href="#">رجالى</a></li>
                                        <li><a href="#">نسائي</a></li>
                                        <li><a href="#">أطفال</a></li>
                                    </ul>
                    			</li>
                            </ul>
                        </li>
                                    
                        <li>
                            <a href="#">الاكثر مشاهده </a>
                        </li>
                        <li>
                            <a href="#">الاعلى تقيما </a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <div class="logo">
                        <img src="images\logo.png" alt="">
                    </div>
                </div>
                <div class="col-lg-2 col-lg-offset-2 col-md-6 col-sm-12">
                    <div class="dropdown hopes">
                        <a href="#">قائمة رغباتى
                        <span class="">(0)</span></a>
                    </div>
                        <!--buy basketin menu-->
                    <div class="buybasket none">
                        <button class="btn buylink "> <i class="flaticon-shopping-cart"></i> </button>
                    </div>
                        <div class="product-table">
                            <div class="product">
                                <ul>
                                    <li><img src="images/im1.png" alt=""></li>
                                    <li>اسم المنتج</li>
                                    <li>1</li>
                                    <li>30ر.س</li>
                                    <li><a href="#"><i class="fas fa-window-close"></i></a></li>
                                </ul>
                                <div class="table">
                                    <table class="table table-bordered">
                                        <tbody>
                                            <tr>
                                                <td class="text-right"><strong>الاجمالي</strong></td>
                                                <td class="text-right">30 ر.س</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>القيمة المضافة</strong></td>
                                                <td class="text-right">2 ر.س</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>الاجمالي النهائي</strong></td>
                                                <td class="text-right">32 ر.س</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <p><a href="#">إنهاء الطلب</a>
                                <a href="#">معاينة السلة</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
</header>
