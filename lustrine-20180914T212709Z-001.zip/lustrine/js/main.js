$(document).ready(function(){

    
    $('.center').slick({
        centerMode: true,
        centerPadding: '0px',
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        vertical:true,
        autoplaySpeed: 2000,
      });
      

    $('.slide1').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        rtl:true,
        dots:false,
        navText:["",""],
        autoplay:true,
        autoplayTimeout:5000,
        responsive:{
            0:{
                items:1
            }
        }
    })
        
    $('.slide2').owlCarousel({
        loop:true,
        margin:10,
        nav:false,
        rtl:true,
        dots:false,
        navText:["",""],
        autoplay:true,
        autoplayTimeout:5000,
        responsive:{
            0:{
                items:1
            },
            400:{
                items:2
            },
            767:{
                items:3
            },
            991:{
                items:5
            }
        }
    })
        
   
    $('.company-logos').owlCarousel({
        loop:true,
        margin:10,
        nav:false,
        rtl:true,
        dots:false,
        navText:["",""],
        autoplay:true,
        autoplayTimeout:5000,
        responsive:{
            0:{
                items:1
            },
            400:{
                items:2
            },
            767:{
                items:3
            },
            991:{
                items:4
            }
        }
    })


// $('.lang li').click(function(){
//     $imgcopy = $(this).children().children().attr('src');
//     $('.choose-lang-img').html($imgcopy);
// })

$('.buylink').click(function(){
    $('.product-table').toggle(300);
})



$(".dropdown").hover(
    function() {
        $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
        $(this).toggleClass('open');
    },
    function() {
        $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
        $(this).toggleClass('open');
    }
);

$('.heart').click(function(){
    $(this).css("color","red");
    $(this).parent().css("display","block");
});
    
$('.side-menu ,.close-link-menu').click(function(){
    $('.navbar').animate({
        width: "toggle"
      },1000);
  
});

AOS.init({
    offset: 100,
    duration: 500,
    easing: 'ease-in-quad',
    delay: 0,
  });
  


$(window).scroll(function() {
    var scrollVal = $(this).scrollTop();
 if ( scrollVal > 50) {
     
     $('.logo-small').css({'background-color':'#eee','position':'fixed'});
 }
   else{
       
     $('.logo-small').css({'background-color':'transparent','position':'relative'});
   }
 
});

});
