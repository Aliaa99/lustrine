<footer>
    <!-- upfooter -->
<div class="upfooter"data-aos="zoom-in"
     data-aos-duration="1000">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="mail-title">
                    <h2>اشترك فى القائمة البريدية</h2>
                    <p>ليصلك كل ماهو جديد</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <form action="">
                    <input type="email" placeholder="ضع بريدك هنا">
                    <button><i class="fab fa-telegram-plane"></i></button>
                </form>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="social-links">
                    <a href="#" class="face"><i class="fab fa-facebook-f"></i><span>فيسبوك</span></a>
                    <a href="#" class="twitter"><i class="fab fa-twitter"></i><span>تويتر</span></a>
                    <a href="#" class="insta"><i class="fab fa-instagram"></i><span>فيسبوك</span></a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="footer" >
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 col-md-4 col-sm-6">
                <h4>الاكثر بحثا</h4>
                <ul>
                    <li><a href="#">ديكور منازل</a></li>
                    <li><a href="#">كراسي</a></li>
                    <li><a href="#">نجف</a></li>
                    <li><a href="#">عطور</a></li>
                    <li><a href="#">ميكاب</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6">
                <h4>معلومات</h4>
                <ul class="">
                    <li><a href="#">من نحن</a></li>
                    <li><a href="#">معلومات الشحن</a></li>
                    <li><a href="#">الخصوصية</a></li>
                    <li><a href="#">شروط الاستخدام</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6">
                <h4>حسابى</h4>
                <ul class="">
                    <li><a href="#">حسابى </a></li>
                    <li><a href="#">طلباتى</a></li>
                    <li><a href="#">قائمة الرغبات</a></li>
                    <li><a href="#">القائمة البريدية</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6">
                <h4>خدمات العملاء </h4>
                <ul>
                    <li><a href="#">اتصل بنا</a></li>
                    <li><a href="#">ارجاع الطلب</a></li>
                    <li><a href="#">خريطة الموقع</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6">
                <h4>اضافات </h4>
                <ul>
                    <li><a href="#">الشركات</a></li>
                    <li><a href="#">قسائم الهدايا</a></li>
                    <li><a href="#">نظام العمولة </a></li>
                    <li><a href="#">العروض المميزه </a></li>
                </ul>
            </div>
        </div>
        <div class="finish">
            <div class="row">
                <div class="col-md-3">
                    <p>جميع الحقوق محفوظة 2018</p>
                </div>
                <div class="col-md-6 center-text">
                    <a href="#"><img src="images\m1.png" alt=""></a>
                    <a href="#"><img src="images\m2.png" alt=""></a>
                    <a href="#"><img src="images\m3.png" alt=""></a>
                    <a href="#"><img src="images\m4.png" alt=""></a>
                </div>
                <div class="col-md-3">
                    <p>تصميم وبرمجة <span>براند</span> </p>
                </div>
            </div>
        </div>
    </div>
</div>




</footer>

<script src="js/jquery.min.js"></script>
<script src="js/popper.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/lightbox.js"></script>
<script src="js/aos.js"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="js/slick.min.js"></script>
<script>
  AOS.init();
</script>

<script src="js/main.js"></script>
</body>
</html>